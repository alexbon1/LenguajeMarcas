import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AgregarEventoDialogComponent } from './agregar-evento-dialog.component';

describe('AgregarEventoDialogComponent', () => {
  let component: AgregarEventoDialogComponent;
  let fixture: ComponentFixture<AgregarEventoDialogComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AgregarEventoDialogComponent]
    });
    fixture = TestBed.createComponent(AgregarEventoDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
