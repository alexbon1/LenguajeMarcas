import { Component } from '@angular/core';

@Component({
  selector: 'app-agregar-evento-dialog',
  templateUrl: './agregar-evento-dialog.component.html',
  styleUrls: ['./agregar-evento-dialog.component.css']
})
export class AgregarEventoDialogComponent {

}
