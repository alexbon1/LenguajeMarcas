import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CalendarioComponent } from './calendario/calendario.component';
import { AgendaComponent } from './agenda/agenda.component';
import { DocumentacionComponent } from './documentacion/documentacion.component';

const routes: Routes = [
  { path: 'calendario', component: CalendarioComponent },
  { path: 'agenda', component: AgendaComponent },
  { path: 'documentacion', component: DocumentacionComponent },
  { path: '', redirectTo: '/calendario', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
